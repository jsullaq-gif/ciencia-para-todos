import React, { useState } from 'react'
import Header from './components/Header'
import Lessons from './components/Lessons'
import Calculator from './components/Calculator'
import Exercises from './components/Exercises'
import Footer from './components/Footer'

export default function App() {
  const [notes, setNotes] = useState('')
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      <Header />
      <main className="max-w-6xl mx-auto p-6 grid gap-6">
        <section className="bg-white rounded-2xl shadow p-6">
          <h2 className="text-xl font-semibold mb-3">Bienvenido a Ciencia para todos</h2>
          <p className="text-slate-700">Explora álgebra lineal con explicaciones claras, ejemplos interactivos y ejercicios prácticos.</p>
        </section>

        <div className="grid md:grid-cols-3 gap-6">
          <div className="md:col-span-2 space-y-6">
            <Lessons />
            <Exercises />
          </div>
          <aside className="space-y-6">
            <Calculator />
            <div className="bg-white p-4 rounded shadow">
              <h3 className="font-semibold mb-2">Notas</h3>
              <textarea value={notes} onChange={e => setNotes(e.target.value)} className="w-full p-2 border rounded" rows={6} />
            </div>
          </aside>
        </div>
      </main>
      <Footer />
    </div>
  )
}
