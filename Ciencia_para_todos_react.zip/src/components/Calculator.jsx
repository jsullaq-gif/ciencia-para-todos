import React, { useState } from 'react'

function parseMatrix(text) {
  try {
    return text.split(';').map(row => row.trim().split(/\s+/).map(Number))
  } catch {
    return []
  }
}

function formatMatrix(M) {
  return M.map(r => r.map(x => Number.isFinite(x) ? x.toFixed(4) : x).join('\t')).join('\n')
}

function det(m) {
  if (m.length !== m[0].length) throw new Error('Matriz no cuadrada')
  const n = m.length
  if (n === 1) return m[0][0]
  if (n === 2) return m[0][0]*m[1][1] - m[0][1]*m[1][0]
  let s = 0
  for (let i=0;i<n;i++) {
    const sub = m.slice(1).map(r => r.filter((_,j)=>j!==i))
    s += ((i%2===0?1:-1) * m[0][i] * det(sub))
  }
  return s
}

export default function Calculator() {
  const [A, setA] = useState('1 2; 3 4')
  const [B, setB] = useState('2 0; 1 2')
  const [out, setOut] = useState('')

  function handleAdd() {
    const MA = parseMatrix(A), MB = parseMatrix(B)
    const R = MA.map((r,i)=> r.map((v,j)=> v + MB[i][j]))
    setOut(formatMatrix(R))
  }

  function handleMul() {
    const MA = parseMatrix(A), MB = parseMatrix(B)
    const filas = MA.length, colsA = MA[0].length, colsB = MB[0].length
    const C = Array.from({length: filas}, ()=> Array(colsB).fill(0))
    for (let i=0;i<filas;i++) for (let j=0;j<colsB;j++) for (let k=0;k<colsA;k++) C[i][j] += MA[i][k]*MB[k][j]
    setOut(formatMatrix(C))
  }

  function handleDet() {
    try {
      const MA = parseMatrix(A)
      setOut(String(det(MA)))
    } catch(e) {
      setOut('Error: ' + e.message)
    }
  }

  return (
    <div id="calculadora" className="bg-white p-4 rounded shadow">
      <h4 className="font-semibold mb-2">Calculadora de matrices</h4>
      <textarea className="w-full p-2 border rounded mb-2" rows={3} value={A} onChange={e=>setA(e.target.value)} />
      <textarea className="w-full p-2 border rounded mb-2" rows={2} value={B} onChange={e=>setB(e.target.value)} />
      <div className="flex gap-2">
        <button onClick={handleAdd} className="px-3 py-2 bg-blue-700 text-white rounded">A + B</button>
        <button onClick={handleMul} className="px-3 py-2 bg-indigo-600 text-white rounded">A × B</button>
        <button onClick={handleDet} className="px-3 py-2 bg-emerald-600 text-white rounded">det(A)</button>
      </div>
      <pre className="mt-3 bg-gray-100 p-3 rounded text-sm whitespace-pre-wrap">{out}</pre>
    </div>
  )
}
