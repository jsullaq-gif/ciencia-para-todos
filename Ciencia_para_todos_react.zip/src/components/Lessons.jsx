import React from 'react'

const LESSONS = [
  { id:1, title: 'Vectores y espacios vectoriales', content: 'Definición de espacio vectorial, subespacios, combinación lineal y dependencia/independencia.'},
  { id:2, title: 'Matrices y operaciones', content: 'Suma, producto, traspuesta, inversa (cuando existe) y su interpretación.'},
  { id:3, title: 'Determinante y rango', content: 'Cálculo del determinante, propiedades y significado del rango.'},
  { id:4, title: 'Sistemas lineales', content: 'Eliminación de Gauss, condiciones de existencia y unicidad.'}
]

export default function Lessons() {
  return (
    <section id="lecciones" className="bg-white p-6 rounded-2xl shadow">
      <h3 className="text-lg font-semibold mb-4">Lecciones</h3>
      <div className="space-y-4">
        {LESSONS.map(l => (
          <article key={l.id} className="border rounded p-4">
            <h4 className="font-semibold">{l.title}</h4>
            <p className="text-slate-700">{l.content}</p>
            <div className="mt-2 text-sm text-slate-500">Ejemplo: \(a(u+v)=au+av\)</div>
          </article>
        ))}
      </div>
    </section>
  )
}
