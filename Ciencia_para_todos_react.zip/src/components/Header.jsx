import React from 'react'

export default function Header() {
  return (
    <header className="bg-blue-700 text-white py-6">
      <div className="max-w-6xl mx-auto px-6 flex items-center justify-between">
        <h1 className="text-2xl font-bold">Ciencia para todos</h1>
        <nav className="space-x-4">
          <a href="#lecciones" className="hover:underline">Lecciones</a>
          <a href="#calculadora" className="hover:underline">Calculadora</a>
          <a href="#ejercicios" className="hover:underline">Ejercicios</a>
          <a href="#contacto" className="hover:underline">Contacto</a>
        </nav>
      </div>
    </header>
  )
}
