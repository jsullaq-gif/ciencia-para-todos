import React from 'react'

export default function Exercises() {
  return (
    <section id="ejercicios" className="bg-white p-6 rounded-2xl shadow">
      <h3 className="text-lg font-semibold mb-3">Ejercicios prácticos</h3>
      <div className="space-y-4">
        <div className="border p-4 rounded">
          <p className="font-semibold">¿Cuándo una matriz es invertible?</p>
          <p className="text-slate-700">Respuesta: cuando su determinante es distinto de cero.</p>
        </div>
        <div className="border p-4 rounded">
          <p className="font-semibold">Calcular el rango de [[1,2],[2,4]]</p>
          <p className="text-slate-700">Respuesta: 1</p>
        </div>
      </div>
    </section>
  )
}
