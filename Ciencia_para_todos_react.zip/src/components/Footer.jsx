import React from 'react'

export default function Footer() {
  return (
    <footer className="bg-blue-700 text-white mt-8">
      <div className="max-w-6xl mx-auto p-6 text-center">
        <p>© 2025 Ciencia para todos. Todos los derechos reservados.</p>
      </div>
    </footer>
  )
}
